"""Budgeted counting research infrastructure; no measured claims at import time."""
