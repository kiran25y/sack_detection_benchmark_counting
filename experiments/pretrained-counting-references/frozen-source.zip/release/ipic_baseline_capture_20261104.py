"""Frozen pretrained reference comparison; inference only, no target truth input."""
import argparse,hashlib,importlib,json,random,time,traceback
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from clarification_capture import CountGD,Geco,tensor_hash,check_prediction
from clarification_common import read,save,sha


def digest(model):
    h=hashlib.sha256()
    for name,t in sorted(model.state_dict().items()):
        if not torch.isfinite(t).all():raise ValueError('Nonfinite state')
        h.update(name.encode());h.update(str((tuple(t.shape),str(t.dtype))).encode())
        h.update(t.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


class ExternalCountGD(CountGD):
    @torch.inference_mode()
    def predict_external(self,image,reference,boxes):
        prompts={'image':reference,'points':[[*b[:2],2.,*b[2:],3.] for b in boxes]}
        normalized,scores=self.author.predict(self.model,self.transform,image,'',prompts,[],[],torch.device('cuda'))
        normalized=np.asarray(normalized).reshape(-1,4);xywh=normalized.copy();xywh[:,:2]-=normalized[:,2:]/2
        xywh*=np.asarray([image.width,image.height,image.width,image.height]);result=xywh.copy();result[:,2:]+=result[:,:2]
        x,xe,b=self.author.preprocess(self.transform,image,prompts)
        return dict(boxes=result.tolist(),scores=np.asarray(scores).reshape(-1).tolist(),image_tensor_sha256=tensor_hash(x),
                    exemplar_image_tensor_sha256=tensor_hash(xe),transformed_boxes=b.tolist(),reference_path='unchanged author external-exemplar predict; empty text; author threshold0.23')


class ExternalGeco(Geco):
    @torch.inference_mode()
    def predict_external(self,image,reference,boxes,identity=False):
        # Preserve the native query forward, shape embedding, mask refinement and
        # postprocess. Only its three exemplar ROI feature sources are external.
        from torchvision.transforms import functional as TF
        from torch.nn import functional as F
        from counting.geometry import postprocess
        module=importlib.import_module(self.model.__class__.__module__)
        x,b,scale,content=self.adapter.preprocess(image,boxes)
        if identity:
            rx=x
        else:
            raw=TF.to_tensor(reference).unsqueeze(0)
            raw=F.interpolate(raw,scale_factor=scale,mode='bilinear',align_corners=False)
            if max(raw.shape[-2:])>1024:raise ValueError('External atlas does not fit native canvas')
            raw=F.pad(raw,(0,1024-raw.shape[-1],0,1024-raw.shape[-2]),value=0)
            rx=TF.normalize(raw,[.485,.456,.406],[.229,.224,.225]).to(x.device)
        features=self.model.backbone(rx)
        reference_levels=[features['vision_features'],features['backbone_fpn'][0],features['backbone_fpn'][1]]
        original=module.roi_align;calls=[]
        def external_roi(src,**kwargs):
            index=len(calls)
            if index>=3:raise ValueError('Unexpected additional exemplar ROI call')
            calls.append(index)
            return original(reference_levels[index],**kwargs)
        try:
            module.roi_align=external_roi
            outputs,*_=self.model(x,b)
        finally:module.roi_align=original
        if calls!=[0,1,2]:raise ValueError('Native exemplar hook coverage changed')
        raw=outputs[0];cpu=lambda t:t.detach().float().cpu().numpy()
        bb,ss=postprocess(cpu(raw['pred_boxes']),cpu(raw['box_v']),cpu(raw['scores']),scale,content)
        return dict(boxes=bb.tolist(),scores=ss.tolist(),image_tensor_sha256=tensor_hash(x),exemplar_image_tensor_sha256=tensor_hash(rx),
                    transformed_boxes=b[0].cpu().tolist(),scale=scale,reference_path='GeCo2 external-reference adapter; native query/head/postprocess unchanged; not an official external-reference result')


def scoped(pred,row):
    boxes=np.asarray(pred['boxes'],float).reshape(-1,4);centers=(boxes[:,:2]+boxes[:,2:])/2
    x0,y0,x1,y1=row['roi_xyxy'];keep=(centers[:,0]>=x0)&(centers[:,0]<x1)&(centers[:,1]>=y0)&(centers[:,1]<y1)
    return dict(**pred,roi_xyxy=row['roi_xyxy'],roi_keep=keep.tolist(),points=centers[keep].tolist(),
                scope_rule='same predeclared coarse foreground region; never point/mask/GT filtering')


def run(a):
    job=Path(a.job);out=job/(a.model+'_'+a.mode);out.mkdir(exist_ok=False);calls=0;backbone_calls=0;start=time.monotonic()
    try:
        protocol=read(job/'protocol.json')
        for rel,h in read(job/'input_hashes.json').items():assert sha(job/rel)==h,rel
        for rel,h in read(job/'release_hashes.json').items():assert sha(Path(__file__).parent/rel)==h,rel
        for path,h in read(job/'external_hashes.json')[a.model].items():assert sha(path)==h,path
        rows=read(job/'inputs.json');guards=read(job/'compatibility_inputs.json')
        allowed={'query_id','image','image_sha256','width','height','dependency_group','roi_xyxy'}
        assert len(rows)==23 and len({r['query_id'] for r in rows})==23 and all(set(r)==allowed for r in rows)
        for row in rows+guards:assert sha(job/row['image'])==row['image_sha256']
        torch.set_num_threads(2);torch.manual_seed(42 if a.model=='countgd' else 2027);np.random.seed(42);random.seed(42)
        torch.backends.cudnn.benchmark=False;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.set_grad_enabled(False)
        save(out/'status.json',dict(state='loading',calls=0,optimizer_steps=0))
        wrapper=ExternalCountGD() if a.model=='countgd' else ExternalGeco();before=digest(wrapper.model)
        assert not wrapper.model.training and all(not p.requires_grad for p in wrapper.model.parameters())
        def hook(*unused):
            nonlocal backbone_calls
            backbone_calls+=1
        handle=wrapper.model.backbone.register_forward_hook(hook)
        reference=Image.open(job/'reference_atlas.png').convert('RGB');boxes=protocol['reference_atlas']['boxes']
        checks=[];cap=protocol['calls'][a.model+'_'+a.mode]
        def forward(row,kind='external'):
            nonlocal calls
            assert calls<cap and not torch.is_grad_enabled()
            image=Image.open(job/row['image']).convert('RGB');t=time.monotonic()
            if kind=='native':
                pred=wrapper.adapter.predict(dict(image=str(job/row['image']),exemplars=[row['source_box_xyxy']]))
            else:
                pred=wrapper.predict_external(image,image if kind=='identity' else reference,[row['source_box_xyxy']] if kind=='identity' else boxes,**({'identity':True} if kind=='identity' else {}))
            torch.cuda.synchronize();calls+=1;check_prediction(pred,row['width'],row['height'])
            record=dict(query_id=row['query_id'],kind=kind,model=a.model,seconds_shared_GPU=time.monotonic()-t,**scoped(pred,row))
            save(out/'status.json',dict(state='capturing',calls=calls,prescribed_calls=cap,query_id=row['query_id'],optimizer_steps=0))
            return record
        with (out/'predictions.jsonl').open('x') as f:
            if a.mode=='preflight':
                if a.model=='geco':
                    for row in guards:
                        original=forward(row,'native');adapted=forward(row,'identity')
                        for key in ('boxes','scores'):np.testing.assert_allclose(adapted[key],original[key],rtol=1e-5,atol=1e-6)
                        checks.append(dict(query_id=row['query_id'],native_identity_parity=True))
                        for record in (original,adapted):f.write(json.dumps(record,allow_nan=False)+'\n');f.flush()
                for row in guards:
                    one=forward(row);two=forward(row)
                    for key in ('boxes','scores','points','transformed_boxes'):np.testing.assert_allclose(one[key],two[key],rtol=1e-5,atol=1e-6)
                    assert one['image_tensor_sha256']==two['image_tensor_sha256'] and one['exemplar_image_tensor_sha256']==two['exemplar_image_tensor_sha256']
                    checks.append(dict(query_id=row['query_id'],external_repeat=True))
                    for record in (one,two):f.write(json.dumps(record,allow_nan=False)+'\n');f.flush()
            else:
                pre=read(job/(a.model+'_preflight/report.json'));assert pre['state']=='completed' and pre['parameters_unmodified'] and pre['calls']==protocol['calls'][a.model+'_preflight']
                for row in rows:f.write(json.dumps(forward(row),allow_nan=False)+'\n');f.flush()
        handle.remove();after=digest(wrapper.model);assert before==after and calls==cap
        report=dict(state='completed',calls=calls,prescribed_calls=cap,model=a.model,mode=a.mode,optimizer_steps=0,persistent_steps=0,
                    parameters_unmodified=True,finite_parameters=True,initial_state_sha256=before,final_state_sha256=after,checks=checks,
                    query_count=len(rows) if a.mode=='bank' else len(guards),backbone_forward_calls=backbone_calls,
                    truth_loaded=False,scores_ready_for_full_cohort=False,elapsed_seconds_shared_GPU=time.monotonic()-start,
                    max_cuda_allocated=torch.cuda.max_memory_allocated(),max_cuda_reserved=torch.cuda.max_memory_reserved(),protocol_sha256=sha(job/'protocol.json'))
        save(out/'report.json',report);save(out/'status.json',report);save(out/'result_hashes.json',{n:sha(out/n) for n in ['report.json','status.json','predictions.jsonl']})
    except Exception:
        save(out/'status.json',dict(state='failed',calls=calls,backbone_forward_calls=backbone_calls,optimizer_steps=0,error=traceback.format_exc()));raise


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',default='/pipeline');p.add_argument('--model',choices=['countgd','geco'],required=True);p.add_argument('--mode',choices=['preflight','bank'],required=True);run(p.parse_args())
