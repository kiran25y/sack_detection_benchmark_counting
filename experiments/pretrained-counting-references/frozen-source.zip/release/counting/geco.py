"""Pinned GeCo2 adapter. Upstream code remains unchanged."""
import os
import sys
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from .geometry import postprocess


class GeCo2:
    def __init__(self, baseline, checkpoint, sam_checkpoint, device="cuda"):
        self.baseline = Path(baseline).resolve()
        sys.path.insert(0, str(self.baseline))
        os.chdir(self.baseline)
        from models.counter_infer import build_model
        from utils.arg_parser import get_argparser
        args = get_argparser().parse_args([])
        args.kernel_dim = 1
        original = torch.hub.load_state_dict_from_url

        def local_sam(url, **kwargs):
            if url != "https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_base_plus.pt":
                raise RuntimeError("Unexpected backbone URL")
            return torch.load(sam_checkpoint, map_location="cpu", weights_only=True)
        torch.hub.load_state_dict_from_url = local_sam
        try:
            model = build_model(args)
        finally:
            torch.hub.load_state_dict_from_url = original
        state = torch.load(checkpoint, map_location="cpu", weights_only=True)["model"]
        state = {k.removeprefix("module."): v for k,v in state.items()}
        loaded = model.load_state_dict(state, strict=False)
        missing = [k for k in loaded.missing_keys if not k.startswith("sam_mask.")]
        if missing:
            raise RuntimeError(f"Counting parameters missing: {missing}")
        self.load_report = {"missing_foundation_keys": loaded.missing_keys,
                            "checkpoint_only_keys": loaded.unexpected_keys, "counting_parameters_loaded": True}
        self.device = torch.device(device)
        self.model = model.eval().to(self.device)

    def preprocess(self, image, exemplars, effective_resolution=False):
        from torchvision.transforms import functional as TF
        from utils.data import resize_and_pad
        x = TF.to_tensor(image)
        b = torch.as_tensor(exemplars, dtype=torch.float32)
        # zero_shot only disables the upstream exemplar-size scaling cap.
        # The model still receives all three supplied exemplars.
        x, b, scale = resize_and_pad(x, b, size=1024.0, zero_shot=effective_resolution)
        content = (int(image.width*scale), int(image.height*scale))
        x = TF.normalize(x, [0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        return x.unsqueeze(0).to(self.device), b.unsqueeze(0).to(self.device), scale, content

    @torch.inference_mode()
    def predict(self, row, effective_resolution=False):
        with Image.open(row["image"]) as im:
            x, b, scale, content = self.preprocess(im.convert("RGB"), row["exemplars"], effective_resolution)
        outputs, *_ = self.model(x, b)
        raw = outputs[0]
        cpu = lambda value: value.detach().float().cpu().numpy()
        boxes, scores = postprocess(cpu(raw["pred_boxes"]), cpu(raw["box_v"]), cpu(raw["scores"]),
                                    scale, content)
        return {"boxes": boxes.tolist(), "scores": scores.tolist(), "scale": scale,
                "raw_box_shape": list(raw["pred_boxes"].shape), "processed_pixels": 1024**2}
