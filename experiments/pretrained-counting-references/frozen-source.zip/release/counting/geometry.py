"""Original-coordinate ownership. Half-open cores assign boundary centers once."""
from dataclasses import dataclass
import numpy as np


def boxes_array(boxes):
    a = np.asarray(boxes, dtype=float)
    if a.size == 0:
        return a.reshape(0, 4)
    if a.ndim == 3 and a.shape[0] == 1:
        a = a[0]
    if a.ndim == 1 and a.shape == (4,):
        a = a.reshape(1, 4)
    if a.ndim != 2 or a.shape[1] != 4 or not np.isfinite(a).all():
        raise ValueError(f"Invalid boxes: {a.shape}")
    return a


def nms(boxes, values, iou=0.5):
    boxes = boxes_array(boxes)
    values = np.asarray(values, dtype=float).reshape(-1)
    if len(values) != len(boxes) or not np.isfinite(values).all():
        raise ValueError("Invalid NMS values")
    order = np.argsort(-values, kind="stable")
    kept = []
    areas = np.maximum(boxes[:, 2:] - boxes[:, :2], 0).prod(1)
    while len(order):
        i = order[0]
        kept.append(i)
        rest = order[1:]
        inter = np.maximum(np.minimum(boxes[i, 2:], boxes[rest, 2:]) -
                           np.maximum(boxes[i, :2], boxes[rest, :2]), 0).prod(1)
        union = areas[i] + areas[rest] - inter
        overlap = np.divide(inter, union, out=np.zeros_like(inter), where=union > 0)
        order = rest[overlap <= iou]
    return np.asarray(kept, dtype=int)


def postprocess(raw_boxes, box_v, scores, scale, content_wh, canvas=1024):
    boxes = boxes_array(raw_boxes)
    values = np.asarray(box_v, dtype=float).reshape(-1)
    scores = np.asarray(scores, dtype=float).reshape(-1)
    if len(values) != len(boxes) or len(scores) != len(boxes):
        raise ValueError("Box/score shape mismatch")
    if scale <= 0 or not np.isfinite(values).all() or not np.isfinite(scores).all():
        raise ValueError("Non-finite predictions or invalid scale")
    if not len(boxes):
        return boxes, scores
    mask = values > values.max() * 0.11
    boxes, values, scores = boxes[mask], values[mask], scores[mask]
    keep = nms(boxes, values, 0.5)
    boxes, scores = np.clip(boxes[keep], 0, 1), scores[keep]
    centers = (boxes[:, :2] + boxes[:, 2:]) * canvas / 2
    valid = (centers[:, 0] < content_wh[0]) & (centers[:, 1] < content_wh[1])
    return boxes[valid] * canvas / scale, scores[valid]


def official_integer_xywh(original_boxes, scale, canvas=1024):
    """Match upstream float32 box_convert -> canvas multiplication -> scale division.

    Casting mathematically equivalent float64 original-coordinate widths directly
    to int can differ by one pixel from the official float32 operation order.
    Unrounded original-coordinate boxes remain the authoritative geometry record.
    """
    original = boxes_array(original_boxes)
    normalized = np.asarray(original * float(scale) / canvas, dtype=np.float32)
    xywh = normalized.copy()
    xywh[:, 2:] = normalized[:, 2:] - normalized[:, :2]
    xywh = xywh * np.float32(canvas) / np.float32(scale)
    return xywh.astype(np.int64)


@dataclass(frozen=True)
class Region:
    id: str
    core: tuple
    halo: tuple


def crop_bank(width, height, grid=2, halo_fraction=0.15):
    if width <= 0 or height <= 0 or grid < 1 or halo_fraction < 0:
        raise ValueError("Invalid crop bank")
    result = []
    for row in range(grid):
        for col in range(grid):
            x0, x1 = width * col / grid, width * (col + 1) / grid
            y0, y1 = height * row / grid, height * (row + 1) / grid
            dx, dy = (x1-x0)*halo_fraction, (y1-y0)*halo_fraction
            # Integer crop bounds, continuous nonoverlapping ownership cores.
            halo = (int(max(0, np.floor(x0-dx))), int(max(0, np.floor(y0-dy))),
                    int(min(width, np.ceil(x1+dx))), int(min(height, np.ceil(y1+dy))))
            result.append(Region(f"r{row}_{col}", (x0, y0, x1, y1), halo))
    return result


def in_core(points, core):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    x0, y0, x1, y1 = core
    return ((points[:, 0] >= x0) & (points[:, 0] < x1) &
            (points[:, 1] >= y0) & (points[:, 1] < y1))


def owned(boxes, core):
    boxes = boxes_array(boxes)
    return in_core((boxes[:, :2] + boxes[:, 2:]) / 2, core)


def merge(base_boxes, base_scores, refinements):
    """Replace global core predictions; never add counts or cross-core NMS."""
    boxes = boxes_array(base_boxes)
    scores = np.asarray(base_scores, dtype=float).reshape(-1)
    if len(scores) != len(boxes):
        raise ValueError("Score length mismatch")
    cores = [r.core for r, _, _ in refinements]
    for i, a in enumerate(cores):
        for b in cores[i+1:]:
            if min(a[2], b[2]) > max(a[0], b[0]) and min(a[3], b[3]) > max(a[1], b[1]):
                raise ValueError("Selected ownership cores overlap")
    keep = np.ones(len(boxes), dtype=bool)
    crops, crop_scores = [], []
    for region, refined, confidence in refinements:
        keep &= ~owned(boxes, region.core)
        refined = boxes_array(refined)
        confidence = np.asarray(confidence, dtype=float).reshape(-1)
        if len(confidence) != len(refined):
            raise ValueError("Refinement score mismatch")
        accepted = owned(refined, region.core)
        crops.append(refined[accepted])
        crop_scores.append(confidence[accepted])
    return np.concatenate([boxes[keep], *crops]), np.concatenate([scores[keep], *crop_scores])
