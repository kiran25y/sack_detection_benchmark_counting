"""Prespecified diagnostic losses, not a novelty claim or threshold repair.

F: original focal + 5*point; U: BCE with uniform negatives; H: BCE with
highest-logit negatives. U/H keep every assigned positive and select 3*N
unmatched valid negatives (32 for an empty image). Assignment is unchanged.
"""
import torch
from torch.nn import functional as F
from counting.ipic.matching import sparse_match
from counting.ipic.losses import huber
from counting.ipic.adaptation_core import adaptation_pair_loss

def selected_negatives(logits,valid,positive_indices,mode,truth_count):
    positive=torch.zeros_like(valid);positive[positive_indices]=True
    candidates=torch.where(valid & ~positive)[0]
    k=min(len(candidates),3*truth_count if truth_count else 32)
    # Perform the same score sort in U and H; selection is the intended difference.
    order=torch.argsort(logits[candidates].detach(),descending=True,stable=True)
    generator=torch.Generator(device='cpu').manual_seed(1729+len(logits)+truth_count)
    uniform=torch.randperm(len(candidates),generator=generator)[:k].to(candidates.device)
    return candidates[order[:k] if mode=='H' else uniform]

def view_loss(output,truth,mode):
    assert mode in ('U','H')
    truth=truth.to(output['points']).reshape(-1,2);ci,gi=sparse_match(output,truth)
    logits=output['logits'].float();ni=selected_negatives(logits,output['valid'],ci,mode,len(truth))
    cls=(F.softplus(-logits[ci]).sum()+F.softplus(logits[ni]).sum())/max(len(truth),1)
    point=huber((output['points'][ci]-truth[gi])/16).sum(1).mean() if len(ci) else logits.sum()*0
    mass=output['probabilities'][output['valid']].float().sum()
    return dict(total=cls+5*point,focal=cls,point=point,count=huber(mass-len(truth)),soft_count=mass,
                positive_examples=len(ci),negative_examples=len(ni))

def pair_loss(a,b,truth_a,truth_b,arm,masks=None,eligible=None,region_valid=None):
    if arm=='F':return adaptation_pair_loss(a,b,truth_a,truth_b,'A',masks,eligible,region_valid)
    av=view_loss(a,truth_a,arm);bv=view_loss(b,truth_b,arm);zero=(a['logits'].sum()+b['logits'].sum())*0
    return dict(total=.5*(av['total']+bv['total']),view_a=av,view_b=bv,global_delta=zero,local_delta=zero,independent_region=zero)

def check_contract():
    logits=torch.tensor([0.,2.,1.,9.,-2.,-3.,-.5,-1.],requires_grad=True)
    valid=torch.tensor([True,True,True,False,True,True,True,True]);positive=torch.tensor([0])
    hard=selected_negatives(logits,valid,positive,'H',1)
    assert hard.tolist()==[1,2,6] and 0 not in hard and 3 not in hard
    uniform=selected_negatives(logits,valid,positive,'U',1)
    assert len(uniform)==3 and len(set(uniform.tolist()))==3 and valid[uniform].all() and 0 not in uniform
    (F.softplus(-logits[positive]).sum()+F.softplus(logits[hard]).sum()).backward()
    assert logits.grad[0]<0 and (logits.grad[hard]>0).all() and logits.grad[3]==0
    assert len(selected_negatives(logits,valid,torch.empty(0,dtype=torch.long),'H',0))==int(valid.sum())
    # Empty labels must still suppress false positives; invalid candidates cannot contribute.
    output=dict(logits=logits,probabilities=logits.sigmoid(),points=torch.zeros(8,2),anchors=torch.zeros(8,2),valid=valid)
    e=view_loss(output,torch.empty(0,2),'H');assert torch.isfinite(e['total']) and e['negative_examples']==7 and e['positive_examples']==0
    return dict(passed=True,hard_negative_identity=True,no_positive_or_invalid_negative=True,correct_gradient_signs=True,empty_scene_supervision=True)
