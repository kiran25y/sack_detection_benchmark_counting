import unittest
import numpy as np
from counting.ipic.adaptation_data import raster_anchor,warp_ids
from counting.ipic.renderer import AmbiguousVisibility

class LabelTransportTests(unittest.TestCase):
    def test_visible_edge_anchor_becomes_unit_member_without_changing_id(self):
        own=np.zeros((8,8),np.int64);own[2:6,2:6]=1
        p=raster_anchor(own,1,[5.5,5.5]);x,y=p.astype(int)
        self.assertTrue(np.all(own[y:y+2,x:x+2]==1))
        np.testing.assert_array_equal(p,[4,4])
        with self.assertRaises(AmbiguousVisibility):raster_anchor(np.eye(8,dtype=int),1,[3,3])
    def test_center_chart_flip_and_identity_preserve_raster(self):
        own=np.arange(24,dtype=np.int32).reshape(4,6)
        geo=dict(matrix=np.eye(3).tolist(),padded_size=(6,4))
        np.testing.assert_array_equal(warp_ids(own,geo),own)
        geo['matrix']=[[-1,0,5],[0,1,0],[0,0,1]]
        np.testing.assert_array_equal(warp_ids(own,geo),own[:,::-1])
if __name__=='__main__':unittest.main()
