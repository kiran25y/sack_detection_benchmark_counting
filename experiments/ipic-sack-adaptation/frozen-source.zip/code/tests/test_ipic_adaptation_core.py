"""CPU-only contracts; toy tensors are not sack labels or a research experiment."""
import unittest
import torch
from counting.ipic.adaptation_core import (
    adaptation_pair_loss, validate_prepared_pair, require_runtime,
    require_screen_admission, initialize_from_foundation, SCREEN_ARMS,
)
from counting.ipic.losses import pair_loss
from counting.ipic.point_fit_diagnostic import point_only_pair


def output(x, p):
    points = torch.tensor(x, dtype=torch.float32).requires_grad_()
    logits = torch.logit(torch.tensor(p)).requires_grad_()
    return dict(points=points, anchors=points.detach().clone(), logits=logits,
                probabilities=logits.sigmoid(), valid=torch.ones(len(p), dtype=torch.bool))


class AdaptationLossTests(unittest.TestCase):
    def setUp(self):
        self.a = output([[5., 5.], [12., 12.]], [.8, .2])
        self.b = output([[6., 5.], [12., 12.]], [.3, .7])
        self.truth = torch.tensor([[5., 5.]])
        mask = torch.zeros((32, 32), dtype=torch.long)
        mask[3:8, 3:8] = 1
        self.masks = (mask, mask)
        self.eligible = (torch.tensor([0., 1.]), torch.tensor([0., 1.]))
        self.valid = torch.tensor([True, True])

    def test_independent_arms_match_approved_objective_and_gradients(self):
        expected = point_only_pair(self.a, self.b, self.truth, self.truth, 'A')['total']
        for arm in ('A', 'C'):
            result = adaptation_pair_loss(self.a, self.b, self.truth, self.truth, arm)
            torch.testing.assert_close(result['total'], expected, rtol=0, atol=0)
            self.assertEqual(result['view_a']['absolute_count_weight'], 0)
            for parameter in (self.a['logits'], self.b['points']):
                actual = torch.autograd.grad(result['total'], parameter, retain_graph=True)[0]
                target = torch.autograd.grad(expected, parameter, retain_graph=True)[0]
                torch.testing.assert_close(actual, target, rtol=0, atol=0)

    def test_relation_controls_keep_spatial_signal_for_zero_net_change(self):
        results = {arm: adaptation_pair_loss(self.a, self.b, self.truth, self.truth, arm,
                    self.masks, self.eligible, self.valid) for arm in SCREEN_ARMS}
        self.assertGreater(float(results['B']['local_delta']), 0)
        torch.testing.assert_close(results['B']['total'] - results['E']['total'],
                                   .25 * results['B']['local_delta'])
        torch.testing.assert_close(results['E']['total'] - results['A']['total'],
                                   .1 * results['E']['global_delta'])
        for left, right in [('A', 'C'), ('B', 'D'), ('E', 'F')]:
            torch.testing.assert_close(results[left]['total'], results[right]['total'], rtol=0, atol=0)
        original = pair_loss(self.a, self.b, self.truth, self.truth, 'B',
                             self.masks, self.eligible, self.valid)
        removed = .05 * (original['view_a']['count'] + original['view_b']['count'])
        torch.testing.assert_close(original['total'] - results['B']['total'], removed)
        for p in (self.a['logits'], self.b['points']):
            expected = torch.autograd.grad(original['total'] - removed, p, retain_graph=True)[0]
            actual = torch.autograd.grad(results['B']['total'], p, retain_graph=True)[0]
            torch.testing.assert_close(actual, expected)

    def test_point_only_pairs_have_no_local_gradient(self):
        b = adaptation_pair_loss(self.a, self.b, self.truth, self.truth, 'B')
        e = adaptation_pair_loss(self.a, self.b, self.truth, self.truth, 'E')
        self.assertEqual(float(b['local_delta']), 0)
        torch.testing.assert_close(b['total'], e['total'], rtol=0, atol=0)
        with self.assertRaisesRegex(ValueError, 'without reviewed'):
            adaptation_pair_loss(self.a, self.b, self.truth, self.truth, 'B', eligible=self.eligible)


def prepared():
    batch = {side: torch.zeros(1, 3, 32, 32) for side in ('a', 'b')}
    batch.update({f'valid_{side}': torch.ones(32, 32, dtype=torch.bool) for side in ('a', 'b')})
    batch.update({f'points_{side}': torch.tensor([[5., 5.]]) for side in ('a', 'b')})
    batch.update(all_products=False, references=torch.zeros(1, 3, 128, 128),
                 reference_boxes=torch.tensor([[2., 2., 126., 126.]]))
    record = dict(split='train', exhaustive_reviewed=True, query_id='toy',
                  dependency_group='toy-group', annotation_type='complete_points',
                  dataset='sacks', count_a=1, count_b=1)
    return batch, record


class AdaptationAdmissionTests(unittest.TestCase):
    def test_partial_development_and_visibility_holds_rejected(self):
        b, r = prepared()
        self.assertTrue(validate_prepared_pair(b, r))
        for key, value in [('split', 'development'), ('exhaustive_reviewed', False),
                            ('label_eligibility_hold', 'invisible'), ('count_a', 2)]:
            changed = dict(r, **{key: value})
            with self.assertRaises(ValueError): validate_prepared_pair(b, changed)

    def test_unverified_zero_and_bad_reference_rejected(self):
        b, r = prepared()
        b['points_a'] = torch.empty(0, 2); r['count_a'] = 0
        with self.assertRaisesRegex(ValueError, 'Unverified zero'): validate_prepared_pair(b, r)
        r['verified_target_absent_a'] = True
        self.assertTrue(validate_prepared_pair(b, r))
        b['reference_boxes'][0, 2] = 129
        with self.assertRaisesRegex(ValueError, 'outside crop'): validate_prepared_pair(b, r)

    def test_point_labels_cannot_become_regional_supervision(self):
        b, r = prepared()
        b.update(ownership=(torch.zeros(32, 32, dtype=torch.long),) * 2,
                 eligible=(torch.tensor([0., 1.]),) * 2, region_valid=torch.tensor([True, True]))
        with self.assertRaisesRegex(ValueError, 'Point-only'): validate_prepared_pair(b, r)
        r.update(annotation_type='complete_masks', paired_mask_audit_passed=True, region_ids=['__background__', 'sack1'])
        with self.assertRaisesRegex(ValueError, 'no visible ownership'): validate_prepared_pair(b, r)
        b['ownership'][0][3:8, 3:8] = 1
        self.assertTrue(validate_prepared_pair(b, r))
        b['eligible'] = (torch.tensor([0., 0.]), torch.tensor([0., 1.]))
        with self.assertRaisesRegex(ValueError, 'Eligibility'): validate_prepared_pair(b, r)

    def test_known_b0_runtime_cannot_admit_b1(self):
        runtime = dict(strict_deterministic_algorithms=True, warn_only=False, supports_B0_only=True)
        require_runtime('A', runtime)
        with self.assertRaisesRegex(ValueError, 'B1 requires'): require_runtime('D', runtime)
        with self.assertRaisesRegex(ValueError, 'Stage admission missing'):
            require_screen_admission({}, 'A', {}, {})

    def test_public_guard_cannot_admit_adaptation(self):
        names = ('official_pretrained_verified coordinate_tests finite_loss_gradients full_assignment_capacity '
                 'two_view_resource_profile tiny_real_set_fit integer_point_fit_verified shared_foundation_verified '
                 'audited_sack_train_points audited_sack_development paired_assets_and_backgrounds_reviewed '
                 'training_pair_manual_audit_200 draw_ledger_frozen').split()
        readiness = dict.fromkeys(names, True)
        with self.assertRaisesRegex(ValueError, 'Actual sack adaptation'):
            require_screen_admission(readiness, 'A', dict(stage='public_foundation_dynamic', passed=True), {})

    def test_wrong_checkpoint_rejected_before_deserialization(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'bad.pt'; p.write_bytes(b'diagnostic-checkpoint-not-accepted')
            with self.assertRaisesRegex(ValueError, 'verified public foundation'):
                initialize_from_foundation(p, 'A')


if __name__ == '__main__': unittest.main()
