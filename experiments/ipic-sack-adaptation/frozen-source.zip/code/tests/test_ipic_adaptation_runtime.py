import unittest
import torch
from counting.ipic.stable_adaptation_runtime import interpolate
from counting.ipic.stable_resampling import bilinear2x

class IntegerResizeTests(unittest.TestCase):
    def test_native_forward_and_cpu_double_adjoint(self):
        for shape in [(1,2,1,3),(1,2,3,5),(1,1,5,1)]:
            for factor in (1,2,4,8):
                torch.manual_seed(19)
                x=torch.randn(shape,dtype=torch.float64,requires_grad=True)
                y=interpolate(x,size=[shape[-2]*factor,shape[-1]*factor],mode='bilinear',align_corners=False)
                native=torch.nn.functional.interpolate(x,scale_factor=factor,mode='bilinear',align_corners=False)
                torch.testing.assert_close(y,native,rtol=0,atol=0)
                g=torch.randn_like(y)
                a=torch.autograd.grad(y,x,g,retain_graph=True)[0]
                b=torch.autograd.grad(native,x,g)[0]
                torch.testing.assert_close(a,b,rtol=1e-12,atol=1e-12)
    def test_retained_b0_forward_and_gradient_exact(self):
        x=torch.randn(1,2,7,9,requires_grad=True)
        a=interpolate(x,size=(14,18),mode='bilinear',align_corners=False)
        b=bilinear2x(x,size=(14,18),mode='bilinear',align_corners=False)
        torch.testing.assert_close(a,b,rtol=0,atol=0)
        g=torch.randn_like(a)
        torch.testing.assert_close(torch.autograd.grad(a,x,g,retain_graph=True)[0],torch.autograd.grad(b,x,g)[0],rtol=0,atol=0)
    def test_unsupported_resize_rejected(self):
        with self.assertRaises(ValueError):interpolate(torch.zeros(1,1,3,5),size=(10,10),mode='bilinear',align_corners=False)
if __name__=='__main__':unittest.main()
