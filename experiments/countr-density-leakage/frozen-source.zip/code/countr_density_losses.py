"""Frozen count-versus-leakage losses; labels are used only during fitting."""
import torch


def terms(raw, target, roi):
    assert raw.shape == target.shape == roi.shape and roi.dtype == torch.bool
    assert bool(roi.any()) and bool((target >= 0).all())
    mse = ((raw - target) ** 2)[roi].mean()
    positive = torch.relu(raw) / 60.0
    predicted_count = positive[roi].sum()
    target_count = target[roi].sum() / 60.0
    count = (predicted_count - target_count).abs()
    leakage = positive[roi & (target == 0)].sum()
    return mse, count, leakage


def objective(raw, target, roi, arm, coefficient):
    mse, count, leakage = terms(raw, target, roi)
    assert arm in ('C', 'L') and coefficient >= 0
    # An exact zero-weight path supports verification against the saved MSE control.
    total = mse if coefficient == 0 else mse + coefficient * (count if arm == 'C' else leakage)
    return total, dict(mse=float(mse.detach()), count=float(count.detach()), leakage=float(leakage.detach()))


def unit_checks():
    # Count agreement can conceal displaced positive mass. ROI and sign matter.
    r = torch.tensor([[30., 30., -60., 900.]], dtype=torch.float64, requires_grad=True)
    t = torch.tensor([[60., 0., 0., 0.]], dtype=torch.float64)
    m = torch.tensor([[True, True, True, False]])
    mse, c, l = terms(r, t, m)
    assert c.item() == 0 and l.item() == .5
    g = torch.autograd.grad(l, r, retain_graph=True)[0]
    torch.testing.assert_close(g, torch.tensor([[0., 1/60, 0., 0.]], dtype=torch.float64), rtol=0, atol=0)
    _, c0, l0 = terms(r, torch.zeros_like(t), m)
    assert c0.item() == l0.item() == 1
    moved = torch.tensor([[0., 60., -60., 900.]], dtype=torch.float64)
    assert terms(moved, t, m)[1].item() == 0 and terms(moved, t, m)[2].item() == 1
    x = torch.tensor([[40., 42., -17., 500.]], dtype=torch.float64, requires_grad=True)
    for arm in ('C', 'L'):
        f, _ = objective(x, t, m, arm, .037)
        grad = torch.autograd.grad(f, x, retain_graph=True)[0]
        for i in range(4):
            plus=x.detach().clone();minus=x.detach().clone();plus[0,i]+=1e-4;minus[0,i]-=1e-4
            numeric=(objective(plus,t,m,arm,.037)[0]-objective(minus,t,m,arm,.037)[0])/2e-4
            torch.testing.assert_close(numeric,grad[0,i],rtol=1e-7,atol=1e-7)
    return dict(roi_and_sign=True, equal_count_displacement=True, empty_equivalence=True, finite_difference=True)
