"""NumPy-only metrics for saved density arrays; not a point-F1 estimator."""
import numpy as np
def score(raw,mask,row):
    raw=np.asarray(raw,dtype=np.float64)/60;density=np.maximum(raw,0)*mask
    H,W=raw.shape;w,h=row['width'],row['height'];pts=np.asarray(row['points']).reshape(-1,2)
    xs=(np.arange(W)+.5)*w/W-.5;ys=(np.arange(H)+.5)*h/H-.5
    n=row['count'];pred=float(density.sum());error=pred-n
    r=dict(query_id=row['image_id'],group=row['dependency_group'],truth=n,prediction=pred,error=error,AE=abs(error),raw_signed_count=float((raw*mask).sum()),negative_mass=float((-np.minimum(raw,0)*mask).sum()))
    for level in (1,2,3):
        k=2**level;gx=np.minimum((xs/w*k).astype(int),k-1);gy=np.minimum((ys/h*k).astype(int),k-1)
        grid=np.bincount((gy[:,None]*k+gx[None,:]).ravel(),weights=density.ravel(),minlength=k*k)
        gt=np.zeros(k*k)
        if n:
            ix=np.minimum((pts[:,0]/w*k).astype(int),k-1);iy=np.minimum((pts[:,1]/h*k).astype(int),k-1);gt=np.bincount(iy*k+ix,minlength=k*k)
        r['GAME'+str(level)]=float(abs(grid-gt).sum())
    # Assign each pixel in a fixed 8px neighborhood (long-side1024) to one nearest label.
    # This prevents a single density mass from being credited to multiple sacks.
    nearest=np.full((H,W),np.inf);owner=np.full((H,W),-1,dtype=np.int32);radius=8*max(w,h)/1024
    for i,(x,y) in enumerate(pts):
        dist=(xs[None,:]-x)**2+(ys[:,None]-y)**2;take=(dist<nearest)&(dist<=radius**2)
        nearest[take]=dist[take];owner[take]=i
    mass=np.bincount(owner[owner>=0],weights=density[owner>=0],minlength=n) if n else np.array([])
    r['spatial_mass_precision_8']=float(mass.sum()/max(pred,1e-12)) if n else None
    r['spatial_mass_recall_8']=float(np.minimum(mass,1).mean()) if n else None
    return r
def summary(rows):
    def agg(rr):
        assert rr
        z={k:float(np.mean([r[k] for r in rr])) for k in ['AE','GAME1','GAME2','GAME3']};z['MAE']=z.pop('AE')
        z.update(queries=len(rr),RMSE=float(np.sqrt(np.mean([r['error']**2 for r in rr]))),bias=float(np.mean([r['error'] for r in rr])),predicted_mass=float(sum(r['prediction'] for r in rr)))
        pp=[r for r in rr if r['truth']>0]
        for k in ['spatial_mass_precision_8','spatial_mass_recall_8']:z[k]=float(np.mean([r[k] for r in pp])) if pp else None
        return z
    return dict(all=agg(rows),low=agg([r for r in rows if 1<=r['truth']<=11]),higher=agg([r for r in rows if r['truth']>=12]),empty=agg([r for r in rows if r['truth']==0]),groups={g:agg([r for r in rows if r['group']==g]) for g in sorted({r['group'] for r in rows})},rows=rows)
def gate(results):
    p=results['P']['development'];checks={};diff={}
    for name in ('B','R'):
        c=results[name]['development'];diff[name]={}
        for bucket,minimum in [('all',max(.5,.1*c['all']['MAE'])),('higher',.1*c['higher']['MAE'])]:
            checks[name+'_'+bucket+'_gain']=c[bucket]['MAE']-p[bucket]['MAE']>=minimum-1e-9
        for bucket,ms in [('all',['RMSE','GAME1','GAME2','GAME3']),('low',['MAE','GAME1','GAME2','GAME3'])]:
            for metric in ms:
                a,b=p[bucket][metric],c[bucket][metric];checks[name+'_'+bucket+'_'+metric]=a<=b+max(.1,.01*b)+1e-9;diff[name][bucket+'_'+metric]=a-b
        for metric in ['MAE','spatial_mass_precision_8','spatial_mass_recall_8']:diff[name][metric]=p['all'][metric]-c['all'][metric]
        # Localization must also not regress, even if count and GAME appear acceptable.
        for metric in ['spatial_mass_precision_8','spatial_mass_recall_8']:checks[name+'_'+metric]=p['all'][metric]>=c['all'][metric]-.01-1e-9
        checks[name+'_empty']=p['empty']['predicted_mass']<=c['empty']['predicted_mass']+.1+1e-9
        for g in c['groups']:
            a,b=p['groups'][g]['MAE'],c['groups'][g]['MAE'];checks[name+'_'+g]=a<=b+max(.1,.01*b)+1e-9;diff[name][g]=a-b
    absolute=dict(MAE=p['all']['MAE']<=7.71739130435,empty=p['empty']['predicted_mass']/p['empty']['queries']<=.5,fitting=results['P']['fitting']['all']['MAE']<=2,
                  spatial_precision=p['all']['spatial_mass_precision_8']>=.5,spatial_recall=p['all']['spatial_mass_recall_8']>=.5)
    return dict(passed=all(checks.values()) and all(absolute.values()),relative_passed=all(checks.values()),absolute_passed=all(absolute.values()),checks=checks,absolute_checks=absolute,signed_differences=diff)
