"""Frozen three-way inference. This worker receives no held-out annotations."""
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image
import counting
from counting.firc.geometry import transform,image_to_model,points_to_native
from counting.firc.model import FIRC,load_official_encoder
from counting.firc.preflight import configure
from counting.firc.tiny_fit import digest,write_json
from proposer_reference import Proposer,propose
from frozen_ops import weak_peaks,support_image,refinements,supplement,sigmoid,features

WORK=Path('/job')
OUT=Path('/output')


def countr_input(im,roi):
    w,h=im.size;W=max(384,16*int(w/h*384/16));H=384
    rgb=np.asarray(im.convert('RGB').resize((W,H),Image.Resampling.BILINEAR))
    xx=(np.arange(W)+.5)/(W/w)-.5;yy=(np.arange(H)+.5)/(H/h)-.5
    x0,y0,x1,y1=roi
    mask=(yy[:,None]>=y0)&(yy[:,None]<y1)&(xx[None,:]>=x0)&(xx[None,:]<x1)
    return rgb,mask


def density(model,refs,rgb,mask):
    h,w=mask.shape
    starts=sorted(set(list(range(0,w-383,128))+[w-384]))
    raw=np.zeros((h,w),np.float64);n=np.zeros_like(raw)
    for left in starts:
        x=torch.from_numpy((rgb[:,left:left+384].astype(np.float32)/255).transpose(2,0,1).copy())[None].cuda()
        raw[:,left:left+384]+=model(x,refs,2)[0].cpu().numpy()
        n[:,left:left+384]+=1
    return np.maximum((raw/n).astype(np.float32).astype(float),0)*mask/60


@torch.inference_mode()
def main():
    plan=json.loads((WORK/'plan.json').read_text());configure()
    for name,expected in plan['remote_hashes'].items():assert digest(Path(name))==expected,name
    counting.__path__.append('/countr/code/counting')
    sys.path.append('/countr/code')
    import countr_sack_worker as cw
    cw.setup()
    c=cw.cm.mae_vit_base_patch16()
    cp=torch.load('/countr/result/P/resume.pt',map_location='cpu',weights_only=True)
    assert cp['steps']==300 and cp['arm']=='P' and cp['seed']==1729
    c.load_state_dict(cp['model'],strict=True);del cp
    c=c.cuda().eval()
    cr=torch.from_numpy(np.load('/countr/data/references.npy').astype(np.float32).transpose(0,3,1,2)/255)[None].cuda()
    encoder=load_official_encoder(Path('/assets/dinov2_vitb14_reg4_pretrain.pth')).requires_grad_(False).cuda().eval()
    f=FIRC(encoder).cuda().eval()
    payload=torch.load('/known/adaptation.pt',map_location='cpu',weights_only=True)
    assert payload['step']==3000 and payload['seed']==1729 and payload['stage']=='adaptation'
    missing=f.load_state_dict(payload['counter'],strict=False)
    assert not missing.unexpected_keys and all(k.startswith('encoder.') for k in missing.missing_keys)
    del payload
    refs=[];boxes=[]
    for i,r in enumerate(plan['references']):
        path=Path('/known')/r['image'];assert digest(path)==r['sha256']
        with Image.open(path) as im:
            t=transform(*im.size,224);t['padded_hw']=[224,224];refs.append(torch.from_numpy(image_to_model(im,t)))
            h,w=t['valid_hw'];boxes.append([i,0,0,w,h])
    refs=torch.stack(refs).cuda();boxes=torch.tensor(boxes,dtype=torch.float32,device='cuda')
    with torch.autocast('cuda',dtype=torch.bfloat16):rt=f.encode(refs)
    pg=Proposer().cuda().eval()
    pg.load_state_dict(torch.load(WORK/'fold3.pt',weights_only=True,map_location='cuda'))
    beta=np.load(WORK/'included.npy',allow_pickle=False)
    projection=torch.as_tensor(np.random.default_rng(1301).normal(size=(768,96)).astype('float32'),device='cuda')
    replay=json.loads((WORK/'replay.json').read_text());finished=[]
    for row in plan['rows']:
        key=row['id'];roi=row['roi'];path=Path(row['path'])
        assert digest(path)==row['sha256'],key
        with Image.open(path) as im:
            w,h=im.size;assert [w,h]==row['size']
            t=transform(w,h,896,roi)
            x=torch.from_numpy(image_to_model(im,t))[None].cuda()
            rgb,mask=countr_input(im,roi)
        with torch.autocast('cuda',dtype=torch.bfloat16):
            v=f(x,refs,boxes,[t['valid_hw']],reference_taps=rt)[0]
            feat=encoder.get_intermediate_layers(x,n=[11],reshape=True,return_class_token=False,norm=True)[0].half()
        xy=points_to_native(v['points'].cpu().numpy(),t);q=v['probabilities'].cpu().numpy()
        base,weak=weak_peaks(xy,q,1024/max(w,h))
        mass=density(c,cr,rgb,mask)
        weights=support_image(mass,mask,xy[weak],w,h)/plan['mean_mass']
        odds=q[weak].astype(float)/(1-q[weak].astype(float))
        weighted=odds*np.clip(weights,.25,4.);k=int(np.count_nonzero(weighted/(1+weighted)>=plan['aligned_cutoff']))
        raw=odds/(1+odds)
        selected=np.concatenate((base,weak[np.lexsort((weak,-raw))[:k]]))
        vote=refinements(xy[selected],xy,q,1024/max(w,h),roi,plan['vote_radius'])[0]['confidence_vote']
        gh,gw=feat.shape[-2:];yy,xx=np.ogrid[:gh,:gw]
        valid=torch.as_tensor((yy*14<t['valid_hw'][0])&(xx*14<t['valid_hw'][1]),device='cuda')
        rad=8*max(w,h)/1024
        b,visual=propose(pg,dict(features=feat,valid=valid,transform=t,radius=rad),projection,True)
        b['key']=key
        s=sigmoid(features(b,{key:visual})@beta)
        included=supplement(vote,np.asarray(b['points']),s,plan['tau'],rad)
        eq=supplement(vote,np.asarray(b['points']),np.array(b['scores']),0,rad,len(included)-len(vote))
        assert len(eq)==len(included)
        result={name:points.tolist() for name,points in [('voting',vote),('verifier88',included),('equal_budget',eq)]}
        assert all(np.isfinite(np.asarray(v)).all() for v in result.values())
        if row['stage']=='replay':
            for mode,pts in result.items():
                p=np.asarray(pts).reshape(-1,2);expect=np.asarray(replay[key][mode]).reshape(-1,2)
                assert p.shape==expect.shape and np.allclose(p,expect,atol=1e-5,rtol=0),(key,mode,p.shape,expect.shape)
        else:
            assert finished.count('replay')==23
            with (OUT/(key+'.json')).open('x') as stream:json.dump(dict(id=key,input_sha256=row['sha256'],predictions=result),stream,allow_nan=False)
        finished.append(row['stage'])
        write_json(OUT/'status.json',dict(stage=row['stage'],completed=len(finished)))
    assert finished==['replay']*23+['held_out']*51
    hashes={p.name:digest(p) for p in OUT.glob('H*.json')}
    assert len(hashes)==51
    write_json(OUT/'report.json',dict(state='completed',replayed=23,sealed_frames=51,optimizer_calls=0,plan_sha256=digest(WORK/'plan.json'),hashes=hashes))


if __name__=='__main__':main()
