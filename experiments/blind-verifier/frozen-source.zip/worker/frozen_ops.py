from collections import defaultdict

import numpy as np

ARMS = ('unchanged', 'uniform', 'confidence_vote', 'opposite')

PRIMARY = 'confidence_vote'

def weak_peaks(xy,q,scale):
    base=np.flatnonzero(q>=.35)
    weak=np.flatnonzero((q>=.025)&(q<.35))
    weak=weak[np.lexsort((weak,-q[weak]))]
    coords=xy*scale
    buckets=defaultdict(list)
    def cell(i):
        return int(np.floor(coords[i,0]/8)),int(np.floor(coords[i,1]/8))
    for i in base:
        buckets[cell(i)].append(i)
    selected=[]
    for i in weak:
        x,y=cell(i)
        neighbors=[j for a in (x-1,x,x+1) for b in (y-1,y,y+1) for j in buckets.get((a,b),())]
        if neighbors and np.any(np.sum((coords[neighbors]-coords[i])**2,axis=1)<=64):continue
        selected.append(i)
        buckets[x,y].append(i)
    return base,np.array(selected,dtype=int)

def support_image(density,mask,xy,width,height):
    h,w=density.shape
    # A square of half-width eight on the published point metric's chart.
    radius=8*max(width,height)/1024
    x,y=xy.T+.5
    extent_x=w/width
    extent_y=h/height
    left=np.clip(np.ceil((x-radius)*extent_x-.5).astype(int),0,w)
    right=np.clip(np.floor((x+radius)*extent_x-.5).astype(int)+1,0,w)
    top=np.clip(np.ceil((y-radius)*extent_y-.5).astype(int),0,h)
    bottom=np.clip(np.floor((y+radius)*extent_y-.5).astype(int)+1,0,h)
    def integral(a):
        table=np.pad(a,((1,0),(1,0))).cumsum(axis=0).cumsum(axis=1)
        return table[bottom,right]-table[top,right]-table[bottom,left]+table[top,left]
    total=integral(density)
    pixels=integral(mask.astype(float))
    return np.maximum(total,0)*int(mask.sum())/np.maximum(pixels,1)

def bounded_vectors(seeds, vectors, lower, upper):
    norms = np.linalg.norm(vectors, axis=1)
    factor = np.minimum(1., np.divide(8., norms, out=np.full_like(norms, np.inf), where=norms > 0))
    available = np.maximum(0., np.minimum(seeds-lower, upper-seeds))
    magnitude = np.abs(vectors)
    bounds = np.divide(available, magnitude, out=np.full_like(vectors, np.inf), where=magnitude > 0)
    factor = np.minimum(factor, bounds.min(axis=1))
    return vectors * factor[:, None]

def refinements(seeds_native, xy_native, q, scale, roi, radius):
    if not len(seeds_native):
        return {method: seeds_native.copy() for method in ARMS}, []
    seeds = seeds_native * scale
    xy = xy_native * scale
    owner = np.full(len(q), -1, dtype=int)
    best_squared = np.full(len(q), np.inf)
    for index, center in enumerate(seeds):
        squared = np.square(xy-center).sum(axis=1)
        closer = (squared <= radius**2) & (squared < best_squared)
        owner[closer] = index
        best_squared[closer] = squared[closer]
    assigned = owner >= 0
    index = owner[assigned]
    offsets = xy[assigned] - seeds[index]
    votes = np.bincount(index, minlength=len(seeds))
    bounds = (np.asarray(roi, dtype=float) - .5) * scale

    def centroid_shift(weights):
        total = np.bincount(index, weights=weights, minlength=len(seeds))
        sums = np.column_stack([np.bincount(index, weights=weights*offsets[:,axis],
                                            minlength=len(seeds)) for axis in (0,1)])
        vectors = np.divide(sums, total[:,None], out=np.zeros_like(sums), where=total[:,None] > 0)
        return bounded_vectors(seeds, vectors, bounds[:2], bounds[2:])

    uniform = centroid_shift(np.ones(len(index)))
    weighted = centroid_shift(q[assigned].astype(float))
    points = {'unchanged':seeds_native, 'uniform':seeds_native+uniform/scale,
              PRIMARY:seeds_native+weighted/scale, 'opposite':seeds_native-weighted/scale}
    for value in points.values():
        assert value.shape == seeds_native.shape and np.isfinite(value).all()
        assert (value*scale >= bounds[:2]-1e-9).all() and (value*scale <= bounds[2:]+1e-9).all()
        assert (np.linalg.norm((value-seeds_native)*scale,axis=1) <= 8+1e-9).all()
    return points, votes.tolist()

def array(x):
    return np.asarray(x,dtype=float).reshape(-1,2)

def sigmoid(logits):
    return 1/(1+np.exp(-np.clip(logits,-40,40)))

def features(b, visual):
    s=np.clip(b['scores'],1e-5,1-1e-5)
    rank=np.linspace(1.,0.,len(s))
    logit=np.log(s/(1-s))/4
    return np.column_stack([visual[b['key']],logit,rank,np.ones(len(s))]).astype(float)

def supplement(seeds,xy,score,tau,radius,quota=None):
    chosen=list(seeds);before=len(chosen)
    for i in np.argsort(-score,kind='stable'):
        if quota is not None and len(chosen)-before>=quota:break
        if score[i]<tau:break
        if chosen and np.linalg.norm(array(chosen)-xy[i],axis=1).min()<=radius:continue
        chosen.append(xy[i])
    return array(chosen)
